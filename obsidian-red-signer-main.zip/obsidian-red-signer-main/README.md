# Red Signer for Obsidian

**Sign your Obsidian notes with Ed25519.**  
Generates a `manifest.json` that stores the file hash, your public key, and a signature.  
Perfect for trusted maintainers in decentralized networks – prove authorship and integrity.

## Features

- 🔑 **One‑click signing** – ribbon icon, editor menu, or command palette  
- 📋 **Copy your public key** directly to clipboard  
- ✅ **Status bar indicator** – shows `✓ Signed` (green) or `Unsigned` (gray)  
- 🔄 **Auto‑detects changes** – updates status when you edit or switch notes  
- 📄 **Creates/updates `manifest.json`** at your vault root  

## Installation

### 1. Install the plugin (manual)

- Download **`main.js`** and **`manifest.json`** from the [Releases](https://github.com/StandardCodebase/obsidian-red-signer/releases) page of this repository (or install the zip file of the repository) then copy/move the plugin folder to (`YourVault/.obsidian/plugins/`**).


### 2. Download the Go binary

The plugin requires a compiled `signer` binary (or `signer.exe` on Windows).

- Go to **[Releases](https://github.com/StandardCodebase/obsidian-red-signer/releases)**.
- Download the file for your operating system:

| OS | File name |
|----|-----------|
| Windows | `signer-windows-x64.exe` |
| macOS (Intel) | `signer-macos-x64` |
| macOS (Apple Silicon) | `signer-macos-arm64` |
| Linux | `signer-linux-x64` |

- Place the downloaded file **inside** the plugin folder:  
  `YourVault/.obsidian/plugins/red-signer/`
- **Rename** it to:
  - `signer` (macOS / Linux)
  - `signer.exe` (Windows)
- **Make it executable** (macOS/Linux only):  
  `chmod +x signer`

### 3. Enable the plugin

- Restart Obsidian (or reload community plugins).
- Go to **Settings → Community plugins** → enable **Red Signer**.

## First use

1. Open any markdown note.
2. Click the **signature icon** (✍️) in the left ribbon.
3. A modal shows your **public key** – copy it and add to your server’s `TrustedMaintainers` list.
4. Click **Sign this note**.  
   - The first time, it will create a private key at `~/.red-network/maintainer.key` (permissions `0600`).  
   - It will also create `manifest.json` in your vault root (if not present).  
   - The note is signed and the manifest is updated.

After that, the **status bar** at the bottom of Obsidian will show `✓ Signed` (green) for that note. If you edit it, the status changes to `Unsigned` (gray) until you sign again.

## How it works

- When you sign, the Go binary calculates the SHA‑256 hash of the file.
- It signs the hash with your Ed25519 private key.
- An entry is added to `manifest.json` using the note’s relative path as the key, with fields:
  - `file_hash`: SHA‑256 of the note  
  - `public_key`: your Ed25519 public key  
  - `signature`: the signature of the hash  
- The Obsidian plugin reads `manifest.json` and compares the current file hash to the stored one, displaying the status.

## Security notes

- The private key is stored at `~/.red-network/maintainer.key` with `0600` permissions (owner read/write only).  
- The Go binary runs locally – you are responsible for trusting it.  
- For server‑side verification, use the public key and the signature in `manifest.json`.  

## Building from source (optional)

### Plugin (TypeScript)

```bash
git clone https://github.com/yourusername/obsidian-red-signer
cd obsidian-red-signer
npm install
npm run build   # or `npx tsc`
